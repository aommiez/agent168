<?php
/**
 * Created by PhpStorm.
 * User: p2
 * Date: 7/16/14
 * Time: 5:28 PM
 */

require_once 'bootstrap.php';

\Main\App::start();